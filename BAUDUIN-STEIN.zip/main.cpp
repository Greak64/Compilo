#include "Automate.h"
#include "Lexer.h"
#include "Symbole.h"

#include <iostream>
#include <vector>

using namespace std;

int main() {

    Automate automate;
    automate.lancer();

    return 0;
}
